<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Client', 'kerge-shortcodes'),
	'description'   => esc_html__('Add an Client', 'kerge-shortcodes'),
	'tab'           => esc_html__('Kerge Elements', 'kerge-shortcodes'),
);