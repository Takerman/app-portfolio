<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'title' => array(
		'label'   => esc_html__('Title', 'kerge-shortcodes'),
		'desc'    => esc_html__('Write some text', 'kerge-shortcodes'),
		'type'    => 'text',
	),
	'subtitle' => array(
		'label'   => esc_html__('Subtitle', 'kerge-shortcodes'),
		'desc'    => esc_html__('Write some text', 'kerge-shortcodes'),
		'type'    => 'text',
	)
);