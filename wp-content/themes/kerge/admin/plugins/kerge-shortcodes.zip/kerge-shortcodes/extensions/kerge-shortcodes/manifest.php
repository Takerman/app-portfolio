<?php

$manifest = array();
$manifest['display'] = false;
$manifest['standalone'] = true;